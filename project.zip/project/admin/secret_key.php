<?php
function generateSecretKey()
{
    return 'admin'; // set the secret key to a fixed value
}

$secretKey = generateSecretKey();
