<footer class="footer">

   &copy; copyright @ <?= date('Y'); ?> by <span>LearnHub</span> | all rights reserved!

</footer>